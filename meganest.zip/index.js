﻿const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// ✅ SECURITY HEADERS with CSP
app.use(helmet({
    contentSecurityPolicy: {
        useDefaults: true,
        directives: {
            "default-src": ["'self'"],
            "script-src": ["'self'"],
            "style-src": ["'self'", "https://fonts.googleapis.com"],
            "font-src": ["https://fonts.gstatic.com"],
            "img-src": ["'self'", "data:"],
        }
    }
}));

// ✅ RATE LIMITING
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    standardHeaders: true,
    legacyHeaders: false,
});
app.use(limiter);

// ✅ FORCE HTTPS IN PRODUCTION
app.use((req, res, next) => {
    if (process.env.NODE_ENV === 'production' && req.headers['x-forwarded-proto'] !== 'https') {
        return res.redirect('https://' + req.headers.host + req.url);
    }
    next();
});

// ✅ STATIC FILES (Including all .html pages)
app.use(express.static(path.join(__dirname), { extensions: ['html'] }));
app.use('/assets', express.static(path.join(__dirname, 'assets'), { dotfiles: 'deny', index: false }));
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
app.use('/products', express.static(path.join(__dirname, 'products'), { dotfiles: 'deny', index: false }));

// ✅ BODY PARSING
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// ✅ CONTACT FORM EMAIL
app.post('/contact', async (req, res) => {
    const { name, email, phone, product, message } = req.body;

    const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT),
        secure: true,
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    const mailOptions = {
        from: `"Meganest Contact Form" <${process.env.EMAIL_USER}>`,
        to: process.env.EMAIL_USER,
        subject: `New Meganest Order from ${name}`,
        html: `
            <h2>New Order Submission</h2>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Phone:</strong> ${phone || 'N/A'}</p>
            <p><strong>Product:</strong> ${product}</p>
            <p><strong>Message:</strong><br>${message}</p>
        `
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log('✅ Email sent successfully.');
        res.redirect('/contact.html');
    } catch (error) {
        console.error('❌ Email failed:', error.message);
        res.status(500).send('Error sending message.');
    }
});

// ✅ 404 HANDLER (keep this LAST)
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, '404.html'));
});

// ✅ START SERVER
app.listen(PORT, () => {
    console.log(`🚀 Meganest site is live at http://localhost:${PORT}`);
});
